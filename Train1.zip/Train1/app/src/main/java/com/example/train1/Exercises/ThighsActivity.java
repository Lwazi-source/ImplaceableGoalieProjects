package com.example.train1.Exercises;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.train1.Thigh_activities.Bodyweight_Lunges;
import com.example.train1.Thigh_activities.Cross_Jacks;
import com.example.train1.Thigh_activities.Jump_Rope;
import com.example.train1.Thigh_activities.Lunge_Back_Kick;
import com.example.train1.Thigh_activities.Side_Skater;

public class ThighsActivity extends ListActivity {
String[] list = {"Lunge_Back_kick","Bodyweight_Lunges","Jump_Rope","Cross_Jacks","Side_Skater"};
    Intent i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
setListAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,list));
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        String pos = list[position];
        try {
            pos.equals("com.example.train1.activities.lunge_back_kick");
            i = new Intent(ThighsActivity.this, Lunge_Back_Kick.class);
        } finally{
            startActivity(i);
        }
        try {
            pos.equals("com.example.train1.activities.bodyweight_lunges");
            i = new Intent(ThighsActivity.this, Bodyweight_Lunges.class);
        } finally{
            startActivity(i);
        }
        try {
            pos.equals("com.example.train1.activities.jump_rope");
            i = new Intent(ThighsActivity.this, Jump_Rope.class);
        } finally{
            startActivity(i);
        }
        try {
            pos.equals("com.example.train1.activities.cross_jacks");
            i = new Intent(ThighsActivity.this, Cross_Jacks.class);
        } finally{
            startActivity(i);
        }
        try {
            pos.equals("com.example.train1.activities.side_skater");
            i = new Intent(ThighsActivity.this, Side_Skater.class);
        } finally{
            startActivity(i);
        }
    }
}