package com.example.train1.Thigh_activities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.train1.R;

public class Bodyweight_Lunges extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bodyweight__lunges);
    }
}