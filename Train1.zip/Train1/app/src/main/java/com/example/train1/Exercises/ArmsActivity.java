package com.example.train1.Exercises;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.train1.Arms_activities.Cobra_Pushups;
import com.example.train1.Arms_activities.Pushups;
import com.example.train1.Arms_activities.Shoulder_Taps;
import com.example.train1.Arms_activities.Supermans;
import com.example.train1.Arms_activities.Tricep_Dips;

public class ArmsActivity extends ListActivity {
    String[] list = {"Pushups","Supermans","Tricep_Dips","Cobra_Pushups","Shoulder_Taps"};
    Intent i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       setListAdapter(new ArrayAdapter<>(ArmsActivity.this, android.R.layout.simple_list_item_1, list));
    }
    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        String pos = list[position];
        try {
            pos.equals("com.example.train1.activities.pushups");
            i = new Intent(ArmsActivity.this, Pushups.class);
        } finally{
            startActivity(i);
        }
        try {
            pos.equals("com.example.train1.activities.supermans");
            i = new Intent(ArmsActivity.this, Supermans.class);
        } finally{
            startActivity(i);
        }
        try {
            pos.equals("com.example.train1.activities.cobra_pushups");
            i = new Intent(ArmsActivity.this, Cobra_Pushups.class);
        } finally{
            startActivity(i);
        }
        try {
            pos.equals("com.example.train1.activities.shoulder_taps");
            i = new Intent(ArmsActivity.this, Shoulder_Taps.class);
        } finally{
            startActivity(i);
        }
        try {
            pos.equals("com.example.train1.activities.tricep_dips");
            i = new Intent(ArmsActivity.this, Tricep_Dips.class);
        } finally{
            startActivity(i);
        }
    }
}