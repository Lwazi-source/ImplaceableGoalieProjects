package com.example.train1.Menu_activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.train1.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Camera extends AppCompatActivity {

    Button btnTakePic;
    BottomNavigationView bottomNavigationView;
    ImageView imageView;
    final static int camdata = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_camera);
        btnTakePic =(Button)findViewById(R.id.btnTakePicture);
        imageView = (ImageView) findViewById(R.id.imageView);
        bottomNavigationView = findViewById(R.id.nav);
        bottomNavigationView.setSelectedItemId(R.id.btncamera);
        btnTakePic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent c = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(c,camdata);
            }
        });

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.btnhome:
                        Intent inn = new Intent(Camera.this, Home.class);
                        Toast.makeText(Camera.this,"HOME",Toast.LENGTH_LONG).show();
                        startActivity(inn);
                        return true;
                    case R.id.btncamera:
                        Toast.makeText(Camera.this,"CAMERA",Toast.LENGTH_LONG).show();
                        return true;
                    case R.id.btnprofile:
                        Intent in = new Intent(Camera.this, Profile.class);
                        Toast.makeText(Camera.this,"PROFILE",Toast.LENGTH_LONG).show();
                        startActivity(in);
                        return true;
                    case R.id.btntraining:
                        Intent intent = new Intent(Camera.this, Training.class);
                        Toast.makeText(Camera.this,"TRAINING SESSION",Toast.LENGTH_LONG).show();
                        startActivity(intent);
                        return true;
                }
                return false;
            }
        });
    }
        @Override
        protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
            super.onActivityResult(requestCode, resultCode, data);
            if (requestCode == camdata && resultCode == RESULT_OK){
                //assert data != null;
                Bitmap bitmap = (Bitmap) data.getExtras().get("data");
                imageView.setImageBitmap(bitmap);
            }

        } //finish();

   /* @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Image_Capture_Code) {
            if (resultCode == RESULT_OK) {
                Bitmap bp = (Bitmap) data.getExtras().get("data");
                btnTakePic.setImageBitmap(bp);
            } else if (resultCode == RESULT_CANCELED) {
                Toast.makeText(Camera.this, "Cancelled", Toast.LENGTH_LONG).show();
            }
        }
    }*/
}