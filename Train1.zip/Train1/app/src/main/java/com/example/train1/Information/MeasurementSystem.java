package com.example.train1.Information;

public class MeasurementSystem {

    public final static  double Lbs = 2.204623;
    public final static double Inches= 0.3937;

    public final static  double Centimetre = 1;
    public final static  double Kilograms = 1;

    //imperial measurements
    public double Inches(double height){
        return  height * Inches;
    }
    public double Lbs(double weight) { return weight * Lbs; }

    //metric measurements
    public double Centimetre(double height){
        return  height * Centimetre;
    }

    public double Kilograms(double weight){
        return weight*Kilograms;
    }
}
