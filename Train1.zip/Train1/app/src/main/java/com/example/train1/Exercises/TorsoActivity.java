package com.example.train1.Exercises;

import androidx.annotation.Nullable;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.train1.Calf_activities.Standing_Calf_Raise;
import com.example.train1.Calf_activities.Walk_on_toes;
import com.example.train1.Torso_activities.Elbow_plank;
import com.example.train1.Torso_activities.Plank;
import com.example.train1.Torso_activities.Pushups;
import com.example.train1.Torso_activities.Scissor_kicks;
import com.example.train1.Torso_activities.Situps;

public class TorsoActivity extends ListActivity {

   String[] list = {"Situps","Pushups","Plank","Scissor_kicks"
           ,"Elbow_Plank","Chest_Dips"};
    Intent i;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setListAdapter(new ArrayAdapter<>(TorsoActivity.this,android.R.layout.simple_list_item_1,list));
    }
    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        String pos = list[position];
        try {
            pos.equals("com.example.train1.activities.pushups");
            i = new Intent(TorsoActivity.this, Pushups.class);
        } finally{
            startActivity(i);
        }
        try {
            pos.equals("com.example.train1.activities.situps");
            i = new Intent(TorsoActivity.this, Situps.class);
        } finally{
            startActivity(i);
        }
        try {
            pos.equals("com.example.train1.activities.plank");
            i = new Intent(TorsoActivity.this, Plank.class);
        } finally{
            startActivity(i);
        }
        try {
            pos.equals("com.example.train1.activities.scissor_kicks");
            i = new Intent(TorsoActivity.this, Scissor_kicks.class);
        } finally{
            startActivity(i);
        }
        try {
            pos.equals("com.example.train1.activities.elbow_plank");
            i = new Intent(TorsoActivity.this, Elbow_plank.class);
        } finally{
            startActivity(i);
        }
    }
}