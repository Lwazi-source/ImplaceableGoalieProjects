package com.example.train1.Menu_activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.train1.Exercises.ArmsActivity;
import com.example.train1.Exercises.CalfActivity;
import com.example.train1.Exercises.StretchActivity;
import com.example.train1.Exercises.ThighsActivity;
import com.example.train1.Exercises.TorsoActivity;
import com.example.train1.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Training extends AppCompatActivity {

    ImageButton ibStretch,ibThighs,ibCalf ,ibArms,ibTorso;
    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_training);

        ibTorso = findViewById(R.id.ibTorso);
        ibArms = findViewById(R.id.ibArms);
        ibCalf = findViewById(R.id.ibCalf);
        ibStretch = findViewById(R.id.ibStretch);
        ibThighs = findViewById(R.id.ibThighs);
        bottomNavigationView = findViewById(R.id.nav);
        bottomNavigationView.setSelectedItemId(R.id.btntraining);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.btnhome:
                        Intent intent = new Intent(Training.this, Home.class);
                        Toast.makeText(Training.this, "HOME", Toast.LENGTH_SHORT).show();
                        startActivity(intent);
                        return true;
                    case R.id.btncamera:
                        Intent i = new Intent(Training.this, Camera.class);
                        Toast.makeText(Training.this, "CAMERA", Toast.LENGTH_SHORT).show();
                        startActivity(i);
                        return true;
                    case R.id.btnprofile:
                        Intent in = new Intent(Training.this, Profile.class);
                        Toast.makeText(Training.this, "PROFILE", Toast.LENGTH_SHORT).show();
                        startActivity(in);
                        return true;
                    case R.id.btntraining:
                        Toast.makeText(Training.this, "TRAINING SESSION", Toast.LENGTH_SHORT).show();
                        return true;
                }
                return false;
            }
        });
        ibTorso.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
                Toast.makeText(Training.this,"Feel the Heat !!",Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Training.this, TorsoActivity.class);
                startActivity(i);
         }
        }); ibArms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Training.this,"Great!",Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Training.this, ArmsActivity.class);
                startActivity(i);
            }
        }); ibThighs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Training.this,"Have a blast.",Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Training.this, ThighsActivity.class);
                startActivity(i);
            }
        }); ibCalf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Training.this,"Calf Time",Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Training.this, CalfActivity.class);
                startActivity(i);
       }

        }); ibStretch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Training.this,"Fresh",Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Training.this, StretchActivity.class);
                startActivity(i);
            }
        });
    }
}
