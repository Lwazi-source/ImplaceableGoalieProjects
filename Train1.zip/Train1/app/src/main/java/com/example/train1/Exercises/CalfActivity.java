package com.example.train1.Exercises;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.train1.Calf_activities.Frog_Jumps;
import com.example.train1.Calf_activities.Standing_Calf_Raise;
import com.example.train1.Calf_activities.Walk_on_toes;

public class CalfActivity extends ListActivity {
    String[] list ={"Frog_Jumps","Standing_Calf_Raise","Walk_on_toes"};
    Intent i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
setListAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list));
    }
    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        String pos = list[position];
        try {
            pos.equals("com.example.train1.activities.frog_jumps");
            i = new Intent(CalfActivity.this, Frog_Jumps.class);
        } finally{
            startActivity(i);
        }
        try {
            pos.equals("com.example.train1.activities.standing_calf_raise");
            i = new Intent(CalfActivity.this, Standing_Calf_Raise.class);
        } finally{
            startActivity(i);
        }
        try {
            pos.equals("com.example.train1.activities.walk_on_toes");
            i = new Intent(CalfActivity.this, Walk_on_toes.class);
        } finally{
            startActivity(i);
        }
    }
}