package com.example.train1.Information;

public class Users {
    String Username;
    String Email;
    String Password;
    String Weight;
    String Height;
    String Bmi;

    public String getBmi() {
        return Bmi;
    }

    public void setBmi(String bmi) {
        Bmi = bmi;
    }

    public String getWeight() {
        return Weight;
    }

    public void setWeight(String weight) {
        Weight = weight;
    }

    public String getHeight() {
        return Height;
    }

    public void setHeight(String height) {
        Height = height;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public Users(String username, String email, String password, String weight, String height, String bmi) {
        Username = username;
        Email = email;
        Password = password;
        Weight = weight;
        Height = height;
        Bmi = bmi;
    }
}
