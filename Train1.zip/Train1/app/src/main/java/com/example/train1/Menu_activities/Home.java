package com.example.train1.Menu_activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.train1.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Home extends AppCompatActivity {
BottomNavigationView bottomNavigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        bottomNavigationView = findViewById(R.id.nav);
        bottomNavigationView.setSelectedItemId(R.id.btnhome);
//setting the selected home


bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.btnhome:
                Toast.makeText(Home.this,"HOME",Toast.LENGTH_LONG).show();
                return true;
            case R.id.btncamera:
                Intent i = new Intent(Home.this, Camera.class);
                Toast.makeText(Home.this,"CAMERA",Toast.LENGTH_LONG).show();
                startActivity(i);
                return true;
            case R.id.btnprofile:
                Intent in = new Intent(Home.this, Profile.class);
                Toast.makeText(Home.this,"PROFILE",Toast.LENGTH_LONG).show();
                startActivity(in);
                return true;
            case R.id.btntraining:
                Intent intent = new Intent(Home.this, Training.class);
                Toast.makeText(Home.this,"TRAINING SESSION",Toast.LENGTH_LONG).show();
                startActivity(intent);
                return true;
        }
        return false;
    }
});
    /*btnCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Home.this,Camera.class);
                startActivity(i);
            }
        });*/
     }

}