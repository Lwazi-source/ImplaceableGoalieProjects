package com.example.train1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.train1.Information.Users;
import com.example.train1.Menu_activities.Home;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
final List<Users>usersList = new ArrayList<>();
DatabaseReference databaseReference;
    Button buttonLogin;
    TextView txtRegister;
    EditText etUsername;
    EditText etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsername=findViewById(R.id.etUsername);
        etPassword=findViewById(R.id.etPassword);
        txtRegister=findViewById(R.id.tvRegister);
        buttonLogin=findViewById(R.id.buttonLogin);

        txtRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,Register.class);
                startActivity(intent);
            }
        });

        final AlertDialog builder = new AlertDialog.Builder(this).create();
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                 /*Intent in = new Intent(MainActivity.this , Home.class);
                 startActivity(in);*/
                databaseReference = FirebaseDatabase.getInstance().getReference("User");
                databaseReference.addValueEventListener(new ValueEventListener() {
                    String u = etUsername.getText().toString();
                    String p = etPassword.getText().toString();

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        String valueU = dataSnapshot.child("Username").getValue(String.class);
                        String valueP = dataSnapshot.child("Password").getValue(String.class);

                        if (u.equals(valueU)) {
                            Toast.makeText(MainActivity.this, "welcome back", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(MainActivity.this, "incorrect information", Toast.LENGTH_LONG).show();
                        }

                        // Read from the database
                        // Toast.makeText(MainActivity.this, "username " + valueU, Toast.LENGTH_SHORT).show();
                        // Log.d("Data is yummy" , valueU + valueP);
                        /*String valueU = dataSnapshot.child("Username ").getValue(String.class);
                        String valueP = dataSnapshot.child("Password ").getValue(String.class);*/
                        final List<String> usersList = new ArrayList<>();

                        String u = etUsername.getText().toString();
                        String p = etPassword.getText().toString();

                        if (u.equals(valueU) && p.equals(valueP)) {
                            usersList.add(valueU);
                            usersList.add(valueP);
                            Toast.makeText(MainActivity.this, "Welcome Back", Toast.LENGTH_LONG).show();
                            // Intent in = new Intent(MainActivity.this ,Home.class);
                            // startActivity(in);
                            //builder.setTitle("icon");
                            //builder.setMessage(valueU + "\n" + valueP);
                        } else {
                            etUsername.setText("");
                            etPassword.setText("");
                            Toast.makeText(MainActivity.this, "either your username or password is wrong or empty", Toast.LENGTH_LONG).show();

                        }

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(MainActivity.this, "dataBase error", Toast.LENGTH_LONG).show();

                        //builder.setTitle("icon");
                        // builder.setMessage(valueU + valueP);
                        // builder.show();
                    }
                });
            }
        });
    }
}


