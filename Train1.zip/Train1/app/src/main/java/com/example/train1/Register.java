package com.example.train1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.example.train1.Information.MeasurementSystem;
import com.example.train1.Information.Users;
import com.example.train1.Menu_activities.Home;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Register extends AppCompatActivity {

//saves to realtime database
    final List<Users> usersList = new ArrayList<>();
    MeasurementSystem measurementSystem = new MeasurementSystem();
    EditText etUsername;
    EditText etPassword;
    EditText etConfirmPassword;
    EditText etEmail;

    EditText etHeight;
    EditText etWeight;
    EditText etBmi;

    RadioButton rdbMetric;
    RadioButton rdbImperial;

    Button buttonConvert;
    Button buttonSignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etUsername = findViewById(R.id.etUsername);
        etEmail = findViewById(R.id.etEmail);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        etPassword = findViewById(R.id.etPassword);

        etHeight = findViewById(R.id.etMeasureHeight);
        etWeight = findViewById(R.id.etMeasureWeight);
        etBmi = findViewById(R.id.etBmi);

        rdbImperial = findViewById(R.id.rdbImperial);
        rdbMetric = findViewById(R.id.rdbMetric);

        buttonConvert = findViewById(R.id.buttonConvert);
        buttonSignUp = findViewById(R.id.buttonSignUp);

//convert the data if needed only
        buttonConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (rdbMetric.isChecked()) {
//metric system
                    double height = Double.parseDouble(etHeight.getText().toString());
                    double weight = Double.parseDouble(etWeight.getText().toString());
                    double centimetre = measurementSystem.Centimetre(height);
                    double kilograms = measurementSystem.Kilograms(weight);
                    etHeight.setText(centimetre + "");
                    etWeight.setText(kilograms + "");
//this is a calculation for the Bmi in the metric system
                    double Perc = (centimetre / 100);
                    double Brack = (Perc * Perc);
                    etBmi.setText("" + kilograms / Brack);
                                                                                                  /* builder.setTitle("Hope");
                                                                                                    builder.setMessage(centimetre + " cm "+"\n"+ kilograms + " kg");
                                                                                                    builder.show();*/
                } else if (rdbImperial.isChecked()) {
//imperial system
                    double height = Double.parseDouble(etHeight.getText().toString());
                    double weight = Double.parseDouble(etWeight.getText().toString());
                    double inch = measurementSystem.Inches(height);
                    double lbs = measurementSystem.Lbs(weight);
                    etHeight.setText(inch + "");
                    etWeight.setText("" + lbs);

//this is a calculation for the Bmi in the imperial system
                    int fixed = 703;
                    double length = inch * inch;
                    double width = weight / length;
                    double max = fixed * width;
                    etBmi.setText("" + max);
                                                                                                    /*builder.setTitle("Hope");
                                                                                                    builder.setMessage(inch + " in "+"\n"+ lbs + " lbs");
                                                                                                    builder.show();*/
                } else {
                    Toast.makeText(Register.this, "error,select something", Toast.LENGTH_LONG).show();
                }

                if (etHeight.toString().isEmpty() || etWeight.toString().isEmpty()) {
                    Toast.makeText(Register.this, "error,please enter height and weight", Toast.LENGTH_LONG).show();
                }
            }
        });

        buttonSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Write a message to the database
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference myRef = database.getReference("User-Details/Information/User");

                String email = etEmail.getText().toString();
                String password = etPassword.getText().toString();
                String height = etHeight.getText().toString();
                String weight = etWeight.getText().toString();
                String bmi = etBmi.getText().toString();
                String username = etUsername.getText().toString();

               /* if (etConfirmPassword.getText().toString() != etPassword.getText().toString()) {
                    Toast.makeText(Register.this, "Passwords do not match,retype passwords !", Toast.LENGTH_LONG).show();

                    etConfirmPassword.setText("");
                    etConfirmPassword.setText("");
                }*/
                Users people = new Users(username, email, password, weight, height, bmi);
                usersList.add(people);

                AlertDialog builder = new AlertDialog.Builder(Register.this).create();

                if (etUsername.getText().toString().isEmpty() || etEmail.getText().toString().isEmpty()) {
                    builder.setTitle("ERROR");
                    builder.setMessage("username or email seems to be empty ,please enter username or email");

                    etUsername.setText("");
                    etEmail.setText("");
                }

                Map<String, Object> maps = new HashMap<>();
                for (int i = 0; i < usersList.size(); i++) {
                    int number = i + 1;
                    myRef.child(""+ number).setValue(usersList.get(i));

                    maps.put("Username " + number , usersList.get(i).getUsername());
                    maps.put("Email " + number , usersList.get(i).getEmail());
                    maps.put("Password " + number , usersList.get(i).getPassword());

                    if (rdbMetric.isChecked()) {
                        maps.put(" Metric " + number + " Height ", usersList.get(i).getHeight());
                        maps.put(" Metric " + number + " Weight ", usersList.get(i).getWeight());
                    } else if (rdbImperial.isChecked()) {
                        maps.put(" Imperial " + number + " Height ", usersList.get(i).getHeight());
                        maps.put(" Imperial " + number + " Weight ", usersList.get(i).getWeight());
                    }
                    maps.put("BMI " + number + " ", usersList.get(i).getBmi());
                }
                myRef.updateChildren(maps);
                Toast.makeText(Register.this, "Welcome To The Family", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(Register.this , Home.class);
                startActivity(i);
            }
        });
    }

}
