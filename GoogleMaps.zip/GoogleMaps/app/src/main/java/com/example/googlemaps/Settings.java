package com.example.googlemaps;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

import java.util.ArrayList;

public class Settings extends AppCompatActivity {
    String unit;
    ConfigFile DB = new ConfigFile(Settings.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        RadioButton metric = findViewById(R.id.mrBtn);
        RadioButton imperial = findViewById(R.id.irBTN);
        Button saveBtn = findViewById(R.id.buttonSettings);
        ArrayList<User> users = DB.getUnit();
        for (int i=0;i<users.size();i++){
            Log.i("DB Output: ",users.get(i).getId()+""+users.get(i).getUnit());
            Toast.makeText(Settings.this,"DB Output: "+users.get(i).getId()+""+users.get(i).getUnit(),Toast.LENGTH_LONG).show();
        }
        if(imperial.callOnClick()){
            imperial.setActivated(true);
            metric.setActivated(false);
            unit="1";

        }else if(metric.callOnClick()){
            imperial.setActivated(false);
            metric.setActivated(true);
            unit="0";
        }
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(Settings.this,MainActivity.class));
                Toast.makeText(Settings.this, "Saved.", Toast.LENGTH_LONG).show();
                Intent i = new Intent(Settings.this, MainActivity.class);
                startActivity(i);
                //ConfigFile bob = new ConfigFile(Integer.parseInt(unit));
            }
        });
    }
}