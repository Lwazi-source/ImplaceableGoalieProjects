package com.example.googlemaps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {

    Button btnLogin;
    TextView textViewRegister;
    EditText editTextUsername, editTextPassword;
    Intent i = new Intent();
    FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);   firebaseAuth = FirebaseAuth.getInstance();
        setContentView(R.layout.activity_login);
        btnLogin = findViewById(R.id.buttonLogin);
        textViewRegister = findViewById(R.id.textViewRegister);
        editTextUsername = findViewById(R.id.editTextTextEmail);
        editTextPassword = findViewById(R.id.editTextTextPassword);

        textViewRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                i = new Intent(Login.this,Register.class);
                startActivity(i);
//                startActivity(new Intent(MainActivity.this,Register.class));
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = editTextUsername.getText().toString();
                String password = editTextPassword.getText().toString();

                /*if (TextUtils.isEmpty(email)){
                    Toast.makeText(Login.this,"Error: Username is empty.",Toast.LENGTH_SHORT).show();
                    return;
                }if (TextUtils.isEmpty(password)){
                    Toast.makeText(Login.this,"Error: Password field is empty.",Toast.LENGTH_SHORT).show();
                    return;
                }
                if (password.length() < 4){
                    Toast.makeText(Login.this,"Error: Password field requires min.4 characters.",Toast.LENGTH_SHORT).show();
                    return;
                }
                firebaseAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(Login.this,"Login Successful",Toast.LENGTH_SHORT).show();
                        i = new Intent(Login.this,MainActivity.class);
                        startActivity(i);
//                     startActivity(new Intent(getApplicationContext(),Map.class));

                        }else {
                            Toast.makeText(Login.this,"Error."+ task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                });*/
               Intent i = new Intent(Login.this,MainActivity.class);
                startActivity(i);
                /*
                if(email.isEmpty()||password.isEmpty()){
                    Toast.makeText(Login.this, "EITHER PASSWORD OR USERNAME WRONG,PLEASE TRY AGAIN", Toast.LENGTH_SHORT).show();
                } if(email.equals("ephraim@gmail.com") || password.equals("12345") ){
                    Toast.makeText(Login.this, "Welcome back", Toast.LENGTH_SHORT).show();
                    i = new Intent(Login.this, MainActivity.class);
                    startActivity(i);
                }*/
            }
        });
    }
}