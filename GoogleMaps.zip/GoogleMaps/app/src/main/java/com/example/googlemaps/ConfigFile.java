package com.example.googlemaps;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class ConfigFile extends SQLiteOpenHelper {
    private SQLiteDatabase db;

    public static final String DATABASE = "setI";
    public static final int DATABASE_VERSION = 2;
    public static final String DATABASE_TABLE_NAME = "user";

    public static final String DATABASE_TABLE_CREATE = "CREATE TABLE "+DATABASE_TABLE_NAME+"("
            +"_id INTEGER PRIMARY KEY AUTOINCREMENT,"
            +"measureUnit INTEGER);";

    public ConfigFile(Context context){
        super(context, DATABASE_TABLE_NAME, null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase){
        sqLiteDatabase.execSQL(DATABASE_TABLE_CREATE);
    }
    public void onUpgrade(SQLiteDatabase sqLiteDatabase,int i,int il){

    }
    public void addUserEntry(int measureUnit,ConfigFile DB){
        db = DB.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put("measureUnit",measureUnit);
        db.insert(DB.DATABASE_TABLE_NAME,null,values);
    }
    public ArrayList<User> getUnit() {
        ArrayList<User> users = new ArrayList<>();

        db = getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from " + ConfigFile.DATABASE_TABLE_NAME, null);
        while (cursor.moveToNext()) {
            String id = cursor.getString(1);
            String unit = cursor.getString(2);
            User user = new User(Integer.parseInt(id), Integer.parseInt(unit));
            users.set(0, user);

        }
        return users;
    }
}
