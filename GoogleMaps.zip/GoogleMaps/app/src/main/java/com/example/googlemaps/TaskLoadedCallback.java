package com.example.googlemaps;

public interface TaskLoadedCallback {
    void onTaskDone(Object... values);
}
