package com.example.googlemaps;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class Register extends AppCompatActivity {

    Button btnRegister;
    EditText editTextUsername, editTextPassword;
    Intent i = new Intent();
    FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        firebaseAuth = FirebaseAuth.getInstance();
        btnRegister = findViewById(R.id.buttonRegister);

        editTextUsername = findViewById(R.id.editTextTextEmail);
        editTextPassword = findViewById(R.id.editTextTextPassword);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = editTextUsername.getText().toString();
                String password = editTextPassword.getText().toString();
                /* if (firebaseAuth.getCurrentUser() != null) {
                    //send to main activity
                    finish();
                }
                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(Register.this, "Error: Username is empty.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(Register.this, "Error: Password field is empty.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (password.length() < 4) {
                    Toast.makeText(Register.this, "Error: Password field requires min.4 characters.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!(TextUtils.isEmpty(email) && TextUtils.isEmpty(password))) {
                    //Toast.makeText(Register.this, "Error: Password field requires min.4 characters.", Toast.LENGTH_SHORT).show();
                    i = new Intent(Register.this, Login.class);
                    startActivity(i);
                    return;
                }
                firebaseAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(Register.this, "Successfully added", Toast.LENGTH_SHORT).show();
                            //i = new Intent(Register.this, Login.class);
                          // startActivity(i);
                        } else {
                            Toast.makeText(Register.this, "Error:" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        } //startActivity(i);
                    }
                });*/
                if(email.contains("ephraim@gmail.com") || password.contains("12345") ){
                    Toast.makeText(Register.this, "Successfully added", Toast.LENGTH_SHORT).show();
                    i = new Intent(Register.this, MainActivity.class);
                    startActivity(i);
                }
            }
        });
    }
}
