package com.example.googlemaps;

public class User {
    public int getUnit() {
        return unit;
    }

    public void setUnit(int unit) {
        this.unit = unit;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public User(int unit, int id) {
        this.unit = unit;
        this.id = id;
    }

    int unit;
    int id;

}
