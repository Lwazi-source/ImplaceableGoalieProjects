package com.example.googlemaps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Profile extends AppCompatActivity {
    EditText name, surname;
    DatabaseReference reff;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        name = (EditText) findViewById(R.id.etName);
        surname = (EditText) findViewById(R.id.etSurname);

        reff = FirebaseDatabase.getInstance().getReference().child("Registered Users").child("Registered Users ");

        reff.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
               /* String email = snapshot.child("email").getValue().toString();*/
                String names = snapshot.child("name").getValue().toString();
                String surnames = snapshot.child("surname").getValue().toString();
              /*  String usernames = snapshot.child("username").getValue().toString();*/

                name.setText(names);
                surname.setText(surnames);

            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
}