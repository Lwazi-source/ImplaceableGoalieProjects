package com.example.googlemaps;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;

import java.text.DecimalFormat;

public class Favourites extends FragmentActivity implements OnMapReadyCallback {
    private double lon;
    private double lat;
    private GoogleMap mMap;
    private Polyline polyLine = null;
    LatLng post1, post2;
    Float distance;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourites);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync( this);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LocationManager locationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        String locProvider = locationManager.NETWORK_PROVIDER;

        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {
            String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION};
            ActivityCompat.requestPermissions(this, permissions, 1);
            return;
        }

        // Add a marker in Sydney and move the camera
        Location lastLoc = locationManager.getLastKnownLocation(locProvider);

        final double lat = lastLoc.getLatitude();
        final double lon = lastLoc.getLongitude();
        final LatLng current = new LatLng(lat, lon);
        mMap.addMarker(new MarkerOptions().position(current).title("Home"));

        LatLng sunnySide = new LatLng(-25.7535, 28.2079);
        LatLng Side = new LatLng(-25.7527, 28.2053);
        post1 = current;
        post2 = sunnySide;
        //mMap.addMarker(new MarkerOptions().position(Side).title("Marker A in sunnySide"));
        mMap.addMarker(new MarkerOptions().position(sunnySide).title("Marker in sunnySide"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sunnySide));
        mMap.animateCamera(CameraUpdateFactory.zoomIn());
        mMap.animateCamera(CameraUpdateFactory.zoomTo(15), 2000, null);


        //  new example.com.mapapplication.FetchURL(MapsActivity.this).execute(getURL(Side,sunnySide ,"driving"),"Driving");
        final Location origin = new Location("origin");
        origin.setLatitude(sunnySide.latitude);
        origin.setLongitude(sunnySide.longitude);

        onTaskDone();
        final Location dest = new Location("origin");
        dest.setLatitude(sunnySide.latitude);
        dest.setLongitude(sunnySide.longitude);
        //FetchURL.execute();
        distance = origin.distanceTo(dest);
        final double to = dest.getLatitude();
        final double des = dest.getLongitude();
        Toast.makeText(this, "Distance: " + new DecimalFormat("###.##").format(distance / 1000), Toast.LENGTH_LONG).show();

        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                mMap.clear();
                mMap.addMarker(new MarkerOptions().position(post1).title(""));
                mMap.addMarker(new MarkerOptions().position(latLng).title(""));
                post2 = latLng;
                Toast.makeText(Favourites.this, "Distance: " + new DecimalFormat("###.##").format(distance / 1000), Toast.LENGTH_LONG).show();
                onTaskDone();
            }
        });
    }

    private String getURL(LatLng origin, LatLng dest, String directMode) {
        String str_origin = "origin" + origin.latitude + "," + origin.longitude;
        String str_dest = "dest" + dest.latitude + "," + dest.longitude;
        String mode = "mode=" + directMode;
        String parameters = str_origin + "&" + str_dest + mode;
        String output = "json";
        String url = "https://maps.googleapis.com/maps/api/directions/" +
                output + "?" + parameters + "&key=" + getString(R.string.google_maps_key);
               /* distance = origin.(dest);
                Toast.makeText(MapsActivity.this,"Distance " + new DecimalFormat("###.##").format(distance/1000 ),Toast.LENGTH_LONG).show();*/
        return url;
    }

    public void onTaskDone(Object... values) {
        if (polyLine == null) {
            //polyLine.remove();
            //polyLine = mMap.addPolyline((PolylineOptions)values[0]);
            //Circle circle = mMap.addCircle(new CircleOptions().center(new LatLng(lat,lon)).radius(10000).strokeColor(Color.GRAY).fillColor(Color.BLUE));
            /*.radius(10000).strokeColor(Color.GRAY).fillColor(Color.BLUE)));*/
            Circle circle = mMap.addCircle(new CircleOptions().center(new LatLng(lat,lon)).radius(10000).strokeColor(Color.GRAY).fillColor(Color.BLUE));
            circle.setVisible(true);
            circle.isVisible();
            polyLine = mMap.addPolyline(new PolylineOptions().add(post1, post2).width(5).color(Color.BLACK));
            polyLine.setVisible(true);
            polyLine.isVisible();
        } else if (polyLine != null) {
            polyLine.remove();
            //polyLine = mMap.addPolyline((PolylineOptions)values[0]);
            polyLine = mMap.addPolyline(new PolylineOptions().add(post1, post2).width(5).color(Color.BLACK));
            polyLine.setVisible(true);

            polyLine.isVisible();
        }
    }
}


