package com.example.googlemaps;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.Circle;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class MapClass extends AppCompatActivity implements OnMapReadyCallback, GoogleApiClient.OnConnectionFailedListener {
    private static final String TAG = "MapClass";
    private static final String FINE_LOCATION = Manifest.permission.ACCESS_FINE_LOCATION;
    private static final String COARSE_LOCATION = Manifest.permission.ACCESS_COARSE_LOCATION;
    private Boolean mLocationPermissionsGranted = false;
    private GoogleMap mMap;
    //private GeoDataClient mGeoDataClient;
   // private  static  final LatLngBounds LAT_LNG_BOUNDS = new LatLngBounds(new LatLng(-40,-168),new LatLng(71, 136));
    private  GoogleApiClient googleApiClient;

    private ImageView mGps;
    private AutoCompleteTextView mSearchText;
    private static final float DEFAULT_ZOOM = 15f;
    private static final int LOCATION_PERMISSIONS_REQUEST_CODE = 1234;
    private Polyline polyLine = null;
    private  FusedLocationProviderClient fusedLocationProviderClient;
    LatLng post1,post2;
    Float distance;
    double lat;
    double lon;
   // private  PlaceAutoCompleteAdapter placeAutoCompleteAdapter;

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        mSearchText = findViewById(R.id.input_search);
        getLocationPermissions();
        mGps = findViewById(R.id.ic_gps);

    }

    private void initMap() {
        Log.d(TAG, "initMap: initializing map");
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFragment.getMapAsync(MapClass.this);
    }
    private void init() {
        Log.d(TAG, "initMap: initializing map");

       /*googleApiClient = new GoogleApiClient.Builder(this).addApi(Places.GEO_DATA_API).addApi(Places.PLACE_DETECTION_API)
                .enableAutoManage(this, this).build();*/
        //mGeoDataClient = Places.getGeoDataClient(this);
        /*placeAutoCompleteAdapter = new PlaceAutoCompleteAdapter(this,Places.getGeoDataClient(this, null),LAT_LNG_BOUNDS,null);
        placeAutoCompleteAdapter = new PlaceAutoCompleteAdapter(this,googleApiClient,LAT_LNG_BOUNDS ,null);
       // placeAutoCompleteAdapter = new PlaceAutoCompleteAdapter(this,mGeoDataClient,LAT_LNG_BOUNDS ,null);
        mSearchText.setAdapter(placeAutoCompleteAdapter);*/
        mSearchText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
          @Override
          public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
              if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE || event.getAction() == event.ACTION_DOWN || event.getAction() == event.KEYCODE_ENTER  ){
                    geoLocate();
                    hideSoftKeyboard();
              }
                  return false;
          }
      });

      mGps.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              Log.d(TAG, "onClick: clicked gps icon");
              getDeviceLocation();
          }
      });
        hideSoftKeyboard();
    }

    private void getDeviceLocation() {
        Log.d(TAG, "getDeviceLocation: getting current device location");
        FusedLocationProviderClient fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(MapClass.this);
        try {
            if (mLocationPermissionsGranted) {
                Task location = fusedLocationProviderClient.getLastLocation();
                location.addOnCompleteListener(new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {
                        if (task.isSuccessful()) {
                            Log.d(TAG, "OnComplete: found location");
                            Location currentLocation = (Location) task.getResult();

                            moveCamera(new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude()), DEFAULT_ZOOM,"My Location");
                            Circle circle = mMap.addCircle(new CircleOptions().center(new LatLng(lat,lon)).radius(10000).strokeColor(Color.GRAY).fillColor(Color.BLUE));
                            circle.setVisible(true);
                            circle.isVisible();
                        } else {
                            Log.d(TAG, "OnComplete: current location is null");
                            Toast.makeText(MapClass.this, "unable to get current location", Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }

        } catch (SecurityException e) {
            Log.e(TAG, "getDeviceLocation: Security Exception:" + e.getMessage());
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        Log.d(TAG, "onMapReady: map is ready");
        mMap = googleMap;
        Toast.makeText(MapClass.this, "Map is ready", Toast.LENGTH_LONG).show();


        if (mLocationPermissionsGranted) {
            getDeviceLocation();
            init();
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                return;
            }
            mMap.setMyLocationEnabled(true);
            mMap.getUiSettings().setMyLocationButtonEnabled(false);
        }
        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                //way();
                // onTaskDone();
                mMap.clear();
                onTaskDone();
                 mMap.addMarker(new MarkerOptions().position(latLng).title("Des"));




                //mMap.addMarker(new MarkerOptions().position(post1).title("home"));


            }
        });
    }
private void moveCamera(LatLng latLng, float zoom , String title){
    Log.d(TAG, "moveCamera: moving camera to: lat:" + latLng.latitude + ", lng:" + latLng.longitude);
    mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng,zoom));
    if (!title.equals("My Location")){
        MarkerOptions markerOptions = new MarkerOptions().position(latLng).title(title);
        mMap.addMarker(markerOptions);
    }
    hideSoftKeyboard();
}
    private void getLocationPermissions(){
        Log.d(TAG,"getLocationPermissions: getting location permissions");
        String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION};
        if (ContextCompat.checkSelfPermission(MapClass.this.getApplicationContext(),FINE_LOCATION ) == PackageManager.PERMISSION_GRANTED){
            if (ContextCompat.checkSelfPermission(MapClass.this.getApplicationContext(),COARSE_LOCATION ) == PackageManager.PERMISSION_GRANTED){
                    mLocationPermissionsGranted = true;
                    initMap();
            }else {
                ActivityCompat.requestPermissions(MapClass.this,permissions,LOCATION_PERMISSIONS_REQUEST_CODE);
            }
        }else {
            ActivityCompat.requestPermissions(MapClass.this,permissions,LOCATION_PERMISSIONS_REQUEST_CODE);
        }
    }
    private  void hideSoftKeyboard(){
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.d(TAG,"onRequestPermissionsResult: called.");
        mLocationPermissionsGranted = false;
        switch (requestCode){
        case LOCATION_PERMISSIONS_REQUEST_CODE:
            if (grantResults.length > 0 /*&& grantResults[0] == PackageManager.PERMISSION_GRANTED*/) {
                for (int i = 0; i< grantResults.length ; i++){
                    if (grantResults[i] != PackageManager.PERMISSION_GRANTED){
                        mLocationPermissionsGranted = false;
                        Log.d(TAG,"onRequestPermissionsResult: permission failed");
                        return;
                    }
                }
                Log.d(TAG,"onRequestPermissionsResult: permission granted");
                mLocationPermissionsGranted = true;
                initMap();
            }
        }
    }
    private void geoLocate(){
        Log.d(TAG,"geoLocate: geo locating");

        String searchString = mSearchText.getText().toString();

        Geocoder geocoder = new Geocoder(MapClass.this);
        List<Address> list = new ArrayList();
        try {
            list = geocoder.getFromLocationName(searchString,1);
        }catch (IOException e){
            Log.e(TAG,"geoLocate: IOException:" + e.getMessage());
        }

        if (list.size() > 0){
            Address address = list.get(0);
            Log.d(TAG,"geoLocate: found a location" + address.toString() );
            Toast.makeText(MapClass.this,address.toString(),Toast.LENGTH_LONG).show();
            moveCamera(new LatLng(address.getLatitude(), address.getLongitude()),DEFAULT_ZOOM,address.getAddressLine(0));
        }

    }
    public void onTaskDone(Object... values){
        if(polyLine == null){
            polyLine = mMap.addPolyline(new PolylineOptions().add(post1,post2).width(5).color(Color.RED));
            polyLine.setVisible(true);
            polyLine.isVisible();
        }else if(polyLine != null){
            polyLine.remove();
            //polyLine = mMap.addPolyline((PolylineOptions)values[0]);
            polyLine = mMap.addPolyline(new PolylineOptions().add(post1,post2).width(5).color(Color.RED));
            polyLine.setVisible(true);
            polyLine.isVisible();
        }
   
    }
   /* public void way(){
        Location origin = new Location("origin");
        origin.setLatitude(post1.latitude);
        origin.setLongitude(post1.longitude);


        Location dest = new Location("Destination");
        dest.setLatitude(post2.latitude);
        dest.setLongitude(post2.longitude);
        distance = origin.distanceTo(dest);
        Toast.makeText(MapClass.this,"Distance: "+new DecimalFormat("###.##").format(distance/1000),Toast.LENGTH_LONG).show();

        onTaskDone();
    }*/
}
